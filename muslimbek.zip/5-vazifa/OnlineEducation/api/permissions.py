

from rest_framework.permissions import BasePermission
from django.utils import timezone
from datetime import timedelta

class CustomPermission(BasePermission):
    message = 'You do not have permission to perform this action.'

    def has_permission(self, request, view):
        # Token-based authentication
        if request.user.is_authenticated:
            # Check time limits
            current_time = timezone.now()
            time_limit = timedelta(minutes=10)  # 10 minutes limit
            if hasattr(request.user, 'last_action'):
                if current_time - request.user.last_action < time_limit:
                    return True
            else:
                request.user.last_action = current_time
                request.user.save()
                return True
        return False