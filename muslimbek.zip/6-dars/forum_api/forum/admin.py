from django.contrib import admin

# Register your models here.
from .models import Topic,Comment,Reply

admin.site.register(Topic)
admin.site.register(Comment)
admin.site.register(Reply)