from rest_framework import permissions
from rest_framework.permissions import BasePermission, SAFE_METHODS

class BookPermission(BasePermission):

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return True
        return request.user.is_authenticated

    def has_object_permission(self, request, view, book):
        if request.method in SAFE_METHODS:
            return True
        return book.author == request.user