from django.contrib import admin
from django.urls import path,include
from .views import BookListAPIView

urlpatterns = [
    path('api/book', BookListAPIView.as_view()),
    path('api/detail/<int:pk>', BookListAPIView.as_view()),
    path('api-auth/',include('rest_framework.urls'))

]